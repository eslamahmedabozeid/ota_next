export const data = [
  {
    id: "01",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: true
  },
  {
    id: "02",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: false
  },
  {
    id: "03",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: true
  },
  {
    id: "04",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: true
  },
  {
    id: "05",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: false
  },
  {
    id: "06",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: false
  },
  {
    id: "07",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: true
  },
  {
    id: "08",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: false
  },
  {
    id: "09",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: true
  },
  {
    id: "10",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: false
  },
  {
    id: "11",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: false
  },
  {
    id: "12",
    invoice: "#99652",
    username: "Prantik Chakraborty",
    date: "21 Jan 2024",
    amount: "996.20",
    isComplete: true
  },


];
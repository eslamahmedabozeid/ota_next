export const countries = [
  {
    id: 1,
    name: "united states",
    rate: "42",
    color: "primary",
    position: {
      lat: 39.82,
      lng: -98.57,
    }
  },
  {
    id: 2,
    name: "Australia",
    rate: "23",
    color: "warning",
    position: {
      lat: -25.27,
      lng: 133.77,
    }
  },
  {
    id: 3,
    name: "Brazil",
    rate: "15",
    color: "success",
    position: {
      lat: -14.23,
      lng: -51.92,
    }
  },
  {
    id: 4,
    name: "Africa",
    rate: "15",
    color: "warning",
    position: {
      lat: 1.65,
      lng: 18.59,
    }
  },
  {
    id: 5,
    name: "Bangladesh",
    rate: "05",
    color: "warning",
    position: {
      lat: 23.68,
      lng: 90.35,
    }
  },
  {
    id: 6,
    name: "india",
    rate: "05",
    color: "info",
    position: {
      lat: 20.59,
      lng: 78.96,
    }
  }
]
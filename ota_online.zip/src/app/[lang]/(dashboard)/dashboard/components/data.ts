
export const data = [
  {
    id: "01",
    page: "www.facebook.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "9,636",
    link: "/"
  },
  {
    id: "02",
    page: "www.linkedin.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "7,636",
    link: "/"
  },
  {
    id: "03",
    page: "www.twitter.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "04",
    page: "www.twitter.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "05",
    page: "www.pinterest.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "06",
    page: "www.twitter.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "07",
    page: "www.youtube.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "08",
    page: "www.linkedin.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "09",
    page: "www.twitter.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "10",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "11",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "12",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "13",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "14",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "15",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "16",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "17",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "18",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "19",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "20",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },
  {
    id: "21",
    page: "www.github.com",
    post: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
    count: "5,636",
    link: "/"
  },

];

